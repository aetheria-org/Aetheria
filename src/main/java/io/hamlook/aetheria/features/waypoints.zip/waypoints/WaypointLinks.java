package io.hamlook.aetheria.features.waypoints;

import io.hamlook.aetheria.utils.UrlOpener;
import io.hamlook.aetheria.utils.compat.ClipboardCompat;

public final class WaypointLinks {

    private static final String PLACEHOLDER = ".invalid";

    public static final String SITE_9_URL = "https://site-9.invalid/";
    public static final String SITE_9_TEXT = "Join the Site-9 Discord for guides and routes";

    private WaypointLinks() {
    }

    public static boolean isConfigured() {
        return !SITE_9_URL.contains(PLACEHOLDER);
    }

    public static WaypointResult openSite9() {
        if (!isConfigured()) {
            return WaypointResult.fail("Site-9 link is not set yet.");
        }
        if (UrlOpener.open(SITE_9_URL)) {
            return WaypointResult.ok("Opened Site-9 in your browser.");
        }
        ClipboardCompat.setClipboard(SITE_9_URL);
        return WaypointResult.fail("Could not open the browser. Link copied.");
    }
}
