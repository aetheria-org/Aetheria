package io.hamlook.aetheria.features.waypoints.ui;

import io.hamlook.aetheria.utils.compat.GuiScreenUtils;
import io.hamlook.aetheria.utils.compat.MinecraftCompat;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiTextField;

import java.util.function.Consumer;
import java.util.function.Function;

public final class WaypointField {

    private final MenuTab owner;
    private final String tag;

    private GuiTextField field;
    private int x, y, w, h;
    private String placeholder;
    @Getter
    private boolean active;
    @Setter
    private boolean error;

    private Function<String, Boolean> onSubmit;
    private Function<String, Boolean> onTab;
    private Runnable onCancel;
    private Consumer<String> onChange;

    public WaypointField(MenuTab owner, String tag) {
        this.owner = owner;
        this.tag = tag;
    }

    public boolean matches(MenuTab owner, String tag) {
        return this.owner == owner && this.tag.equals(tag);
    }

    public WaypointField bounds(int x, int y, int w, int h) {
        this.x = x;
        this.y = y;
        this.w = Math.max(20, w);
        this.h = h;
        return this;
    }

    public WaypointField placeholder(String text) {
        this.placeholder = text;
        return this;
    }

    public WaypointField text(String value) {
        ensure().setText(value == null ? "" : value);
        GuiScreenUtils.cursorTextFieldToEnd(field);
        return this;
    }

    public WaypointField maxLength(int length) {
        GuiScreenUtils.setTextFieldMaxLength(ensure(), length);
        return this;
    }

    public WaypointField onSubmit(Function<String, Boolean> handler) {
        this.onSubmit = handler;
        return this;
    }

    public WaypointField onTab(Function<String, Boolean> handler) {
        this.onTab = handler;
        return this;
    }

    public WaypointField onCancel(Runnable handler) {
        this.onCancel = handler;
        return this;
    }

    public WaypointField onChange(Consumer<String> handler) {
        this.onChange = handler;
        return this;
    }

    public String value() {
        return field == null ? "" : field.getText();
    }

    public boolean submit() {
        if (onSubmit == null) return true;
        return onSubmit.apply(value());
    }

    public void cancel() {
        if (onCancel != null) onCancel.run();
    }

    public boolean tab() {
        return onTab != null && onTab.apply(value());
    }

    private GuiTextField ensure() {
        if (field == null) {
            FontRenderer fr = MinecraftCompat.getFontRenderer();
            field = GuiScreenUtils.createTextField(fr, x, y, w, h);
            GuiScreenUtils.setTextFieldBackground(field, false);
            GuiScreenUtils.setTextFieldCanLoseFocus(field, true);
            GuiScreenUtils.setTextFieldMaxLength(field, 64);
        }
        return field;
    }

    public void activate() {
        GuiTextField f = ensure();
        GuiScreenUtils.setX(f, x);
        GuiScreenUtils.setY(f, y);
        GuiScreenUtils.setW(f, w);
        GuiScreenUtils.setH(f, h);
        f.setFocused(true);
        GuiScreenUtils.cursorTextFieldToEnd(f);
        active = true;
        error = false;
    }

    public void deactivate() {
        if (field != null) field.setFocused(false);
        active = false;
        error = false;
    }

    public void render(int mouseX, int mouseY) {
        if (!active) return;
        GuiTextField f = ensure();
        GuiScreenUtils.setX(f, x);
        GuiScreenUtils.setY(f, y);
        GuiScreenUtils.setW(f, w);
        GuiScreenUtils.setH(f, h);
        GuiScreenUtils.tickTextField(f);
        WaypointUi.rect(x, y, w, h, WaypointUi.INSET);
        WaypointUi.border(x, y, w, h, error ? WaypointUi.DANGER : WaypointUi.ACCENT);
        GuiScreenUtils.renderTextField(f, mouseX, mouseY);
        String text = f.getText();
        if ((text == null || text.isEmpty()) && placeholder != null) {
            WaypointUi.text(MinecraftCompat.getFontRenderer(), placeholder, x + 4, y + 4, WaypointUi.MUTED);
        }
    }

    public boolean click(int mouseX, int mouseY, int button) {
        if (!active) return false;
        if (button != 0) return false;
        ensure().mouseClicked(mouseX, mouseY, button);
        return inside(mouseX, mouseY);
    }

    public boolean type(char typedChar, int keyCode) {
        if (!active) return false;
        boolean used = GuiScreenUtils.typeTextField(ensure(), typedChar, keyCode);
        if (used) {
            error = false;
            if (onChange != null) onChange.accept(value());
        }
        return used;
    }

    public boolean inside(int mouseX, int mouseY) {
        return mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
    }
}
